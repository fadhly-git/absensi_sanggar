import React from 'react';

const TempPage: React.FC = () => {
    return <p>hi</p>;
};

export default TempPage;
